import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      doctors: {
        Row: {
          id: string;
          name: string;
          specialty: string;
          bio: string;
          experience_years: number;
          rating: number;
          consultation_price: number;
          image_url: string;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['doctors']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['doctors']['Insert']>;
      };
      medications: {
        Row: {
          id: string;
          name: string;
          generic_name: string;
          active_ingredient: string;
          indications: string;
          dosage: string;
          side_effects: string;
          image_url: string;
          category: string;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['medications']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['medications']['Insert']>;
      };
      bookings: {
        Row: {
          id: string;
          user_id: string | null;
          doctor_id: string;
          session_type: 'video' | 'voice' | 'text';
          patient_name: string;
          patient_email: string;
          patient_phone: string;
          notes: string;
          status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
          scheduled_at: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['bookings']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['bookings']['Insert']>;
      };
      contacts: {
        Row: {
          id: string;
          name: string;
          email: string;
          phone: string;
          session_type: string;
          message: string;
          is_read: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['contacts']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['contacts']['Insert']>;
      };
      profiles: {
        Row: {
          id: string;
          full_name: string;
          phone: string;
          avatar_url: string;
          role: 'user' | 'admin';
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>;
      };
    };
  };
};