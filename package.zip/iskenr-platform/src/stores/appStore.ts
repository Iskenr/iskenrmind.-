import { create } from 'zustand';

interface AppState {
  // User state
  user: { id: string; email: string; role: 'user' | 'admin' } | null;
  setUser: (user: AppState['user']) => void;

  // UI state
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;

  // Toast notifications
  toasts: Array<{ id: string; type: 'success' | 'error' | 'info'; message: string }>;
  addToast: (type: 'success' | 'error' | 'info', message: string) => void;
  removeToast: (id: string) => void;

  // Modal state
  modal: { isOpen: boolean; type: string; data?: unknown } | null;
  openModal: (type: string, data?: unknown) => void;
  closeModal: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),

  isMenuOpen: false,
  setIsMenuOpen: (isMenuOpen) => set({ isMenuOpen }),

  toasts: [],
  addToast: (type, message) => {
    const id = Date.now().toString();
    set((state) => ({
      toasts: [...state.toasts, { id, type, message }]
    }));
    setTimeout(() => {
      set((state) => ({
        toasts: state.toasts.filter((t) => t.id !== id)
      }));
    }, 5000);
  },
  removeToast: (id) => set((state) => ({
    toasts: state.toasts.filter((t) => t.id !== id)
  })),

  modal: null,
  openModal: (type, data) => set({ modal: { isOpen: true, type, data } }),
  closeModal: () => set({ modal: null })
}));