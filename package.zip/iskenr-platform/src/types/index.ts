// Types for the application

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  bio: string;
  experience_years: number;
  rating: number;
  consultation_price: number;
  image_url: string;
  is_active: boolean;
}

export interface Medication {
  id: string;
  name: string;
  generic_name: string;
  active_ingredient: string;
  indications: string;
  dosage: string;
  side_effects: string;
  image_url: string;
  category: string;
  is_active: boolean;
}

export interface Booking {
  id: string;
  user_id: string | null;
  doctor_id: string;
  session_type: 'video' | 'voice' | 'text';
  patient_name: string;
  patient_email: string;
  patient_phone: string;
  notes: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  scheduled_at: string;
  created_at: string;
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  session_type: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
}

export interface Stats {
  label: string;
  value: string;
  suffix?: string;
}