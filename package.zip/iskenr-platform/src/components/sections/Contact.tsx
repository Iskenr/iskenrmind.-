import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Mail, Phone, Clock, Send } from 'lucide-react';

const contactSchema = z.object({
  name: z.string().min(2, 'الاسم مطلوب'),
  email: z.string().email('بريد إلكتروني غير صالح'),
  phone: z.string().optional(),
  session_type: z.enum(['video', 'voice', 'text']),
  message: z.string().min(10, 'الرسالة يجب أن تكون 10 أحرف على الأقل')
});

type ContactFormData = z.infer<typeof contactSchema>;

const Contact = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting }
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema)
  });

  const onSubmit = async (data: ContactFormData) => {
    // Handle form submission
    console.log('Form submitted:', data);
    // Here you would typically send the data to Supabase
  };

  return (
    <section className="py-24 bg-white" id="contact">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title">تواصل معنا</h2>
          <p className="section-subtitle">
            نحن هنا لدعمكم - اختر الطريقة المناسبة لك
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="card p-8"
          >
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium mb-2">الاسم</label>
                <input
                  type="text"
                  {...register('name')}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] transition-colors"
                  placeholder="أدخل اسمك الكامل"
                />
                {errors.name && (
                  <p className="text-[var(--error)] text-sm mt-1">{errors.name.message}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  {...register('email')}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] transition-colors"
                  placeholder="example@email.com"
                />
                {errors.email && (
                  <p className="text-[var(--error)] text-sm mt-1">{errors.email.message}</p>
                )}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium mb-2">رقم الهاتف (اختياري)</label>
                <input
                  type="tel"
                  {...register('phone')}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] transition-colors"
                  placeholder="+966 XX XXX XXXX"
                />
              </div>

              {/* Session Type */}
              <div>
                <label className="block text-sm font-medium mb-3">نوع الجلسة</label>
                <div className="flex gap-4">
                  {[
                    { value: 'video', label: 'فيديو', icon: '📹' },
                    { value: 'voice', label: 'صوت', icon: '📞' },
                    { value: 'text', label: 'رسائل', icon: '💬' }
                  ].map((option) => (
                    <label
                      key={option.value}
                      className="flex-1 cursor-pointer"
                    >
                      <input
                        type="radio"
                        {...register('session_type')}
                        value={option.value}
                        className="peer hidden"
                      />
                      <div className="p-4 border-2 border-gray-200 rounded-lg text-center peer-checked:border-[var(--primary)] peer-checked:bg-[var(--primary)]/5 transition-all">
                        <span className="text-2xl">{option.icon}</span>
                        <p className="mt-2 font-medium">{option.label}</p>
                      </div>
                    </label>
                  ))}
                </div>
                {errors.session_type && (
                  <p className="text-[var(--error)] text-sm mt-1">{errors.session_type.message}</p>
                )}
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-medium mb-2">رسالتك</label>
                <textarea
                  {...register('message')}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] transition-colors resize-none"
                  placeholder="اكتب رسالتك هنا..."
                />
                {errors.message && (
                  <p className="text-[var(--error)] text-sm mt-1">{errors.message.message}</p>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span className="spinner" />
                ) : (
                  <>
                    <Send className="w-5 h-5 flip-rtl" />
                    إرسال
                  </>
                )}
              </button>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Info Cards */}
            <div className="card p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center shrink-0">
                <Mail className="w-6 h-6 text-[var(--primary)] flip-rtl" />
              </div>
              <div>
                <h4 className="font-bold mb-1">البريد الإلكتروني</h4>
                <a href="mailto:haydariiskenr500@gmail.com" className="text-[var(--text-secondary)] hover:text-[var(--primary)]">
                  haydariiskenr500@gmail.com
                </a>
              </div>
            </div>

            <div className="card p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6 text-[var(--primary)] flip-rtl" />
              </div>
              <div>
                <h4 className="font-bold mb-1">رقم الهاتف</h4>
                <a href="tel:+919515788653" className="text-[var(--text-secondary)] hover:text-[var(--primary)]">
                  +919515788653
                </a>
              </div>
            </div>

            <div className="card p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6 text-[var(--primary)] flip-rtl" />
              </div>
              <div>
                <h4 className="font-bold mb-1">ساعات العمل</h4>
                <p className="text-[var(--text-secondary)]">متاحون على مدار الساعة</p>
              </div>
            </div>

            {/* Quote */}
            <div className="card p-8 bg-gradient-to-br from-[var(--primary)] to-[var(--primary-light)] text-white">
              <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: 'Cairo' }}>
                حيدر إسكنير
              </h3>
              <p className="text-white/90 leading-relaxed">
                نحن هنا لدعمكم في رحلتكم نحو صحة نفسية أفضل، بخطوات واثقة وآمنة. نلتزم بتقديم خدمة مبنية على السرية التامة، المهنية، والاحترام.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;