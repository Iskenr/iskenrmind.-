import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Brain, Users, Target, Video } from 'lucide-react';

const services = [
  {
    icon: Brain,
    title: 'الاستشارات النفسية الفردية',
    description: 'جلسات مهنية لمساعدة الأفراد على التعامل مع القلق، الاكتئاب، الضغوط اليومية، واضطرابات المزاج.',
    features: ['علاج القلق والاكتئاب', 'إدارة الضغوط', 'تحسين النوم', 'بناء الثقة بالنفس']
  },
  {
    icon: Users,
    title: 'الإرشاد الأسري والزوجي',
    description: 'دعم العلاقات وتحسين التواصل داخل الأسرة ومعالجة الخلافات بشكل بنّاء.',
    features: ['تحسين التواصل', 'حل النزاعات', 'تقوية الروابط', 'إرشاد الأزواج']
  },
  {
    icon: Target,
    title: 'العلاج السلوكي المعرفي (CBT)',
    description: 'تقنيات علمية فعّالة لتغيير الأنماط الفكرية والسلوكية السلبية.',
    features: ['تحليل الأفكار', 'تغيير المعتقدات', 'حل المشكلات', 'منع الانتكاس']
  },
  {
    icon: Video,
    title: 'الدعم النفسي عن بُعد',
    description: 'جلسات عبر الإنترنت (فيديو أو صوت أو رسائل) بما يتناسب مع احتياجات العميل.',
    features: ['جلسات فيديو', 'مكالمات صوتية', 'رسائل خاصة', 'مرونة في المواعيد']
  }
];

const Services = () => {
  return (
    <section className="py-24 bg-white" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title">خدماتنا</h2>
          <p className="section-subtitle">
            نقدم مجموعة شاملة من الخدمات النفسية الاحترافية المصممة لتلبية احتياجاتك
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="card p-6 group hover:border-[var(--primary)]"
            >
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[var(--primary)]/10 to-[var(--primary-light)]/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <service.icon className="w-8 h-8 text-[var(--primary)]" />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ fontFamily: 'Cairo' }}>
                {service.title}
              </h3>
              <p className="text-[var(--text-secondary)] mb-4 leading-relaxed">
                {service.description}
              </p>
              <ul className="space-y-2 mb-6">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                    <span className="w-1.5 h-1.5 bg-[var(--primary)] rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Link
                to="/booking"
                className="btn-ghost inline-flex items-center gap-2 text-[var(--primary)]"
              >
                احجز الآن
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;