import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 right-20 w-96 h-96 bg-[var(--primary)] rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-[var(--accent)] rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 bg-[var(--primary)]/10 px-4 py-2 rounded-full">
              <span className="w-2 h-2 bg-[var(--primary)] rounded-full animate-pulse" />
              <span className="text-[var(--primary)] font-medium">الطب النفسي الرقمي</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              خدمات العملاء والاستشارات النفسية
              <span className="block text-[var(--primary)] mt-2">مع الاستشاري النفسي</span>
            </h1>

            <p className="text-xl text-[var(--text-secondary)] leading-relaxed">
              نقدّم خدمات متكاملة في مجال الاستشارات النفسية الرقمية، حيث يمكنكم الحصول على دعم نفسي متخصص وآمن من أي مكان، عبر وسائل تواصل حديثة تضمن الخصوصية والراحة.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link to="/booking" className="btn-primary inline-flex items-center gap-2">
                <span>ابدأ رحلتك الآن</span>
                <ArrowRight className="w-5 h-5 flip-rtl" />
              </Link>
              <Link to="/services" className="btn-secondary">
                اكتشف خدماتنا
              </Link>
            </div>

            {/* Trust Badges */}
            <div className="flex items-center gap-8 pt-8">
              <div className="text-center">
                <p className="text-3xl font-bold text-[var(--primary)]">+1000</p>
                <p className="text-sm text-[var(--text-secondary)]">جلسة ناجحة</p>
              </div>
              <div className="w-px h-12 bg-gray-200" />
              <div className="text-center">
                <p className="text-3xl font-bold text-[var(--primary)]">+50</p>
                <p className="text-sm text-[var(--text-secondary)]">طبيب معتمد</p>
              </div>
              <div className="w-px h-12 bg-gray-200" />
              <div className="text-center">
                <p className="text-3xl font-bold text-[var(--primary)]">100%</p>
                <p className="text-sm text-[var(--text-secondary)]">سرية تامة</p>
              </div>
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&h=700&fit=crop"
                alt="استشارة نفسية"
                className="w-full max-w-md mx-auto rounded-3xl shadow-2xl"
              />
            </div>
            {/* Decorative Elements */}
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-[var(--accent)]/20 rounded-full blur-2xl" />
            <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-[var(--primary)]/20 rounded-full blur-2xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;