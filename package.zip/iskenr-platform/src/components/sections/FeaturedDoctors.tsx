import { motion } from 'framer-motion';
import { Star, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Doctor } from '../../types';

interface FeaturedDoctorsProps {
  doctors: Doctor[];
}

const FeaturedDoctors = ({ doctors }: FeaturedDoctorsProps) => {
  // Display only first 3 doctors as featured
  const featuredDoctors = doctors.slice(0, 3);

  return (
    <section className="py-24 bg-[var(--background)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="section-title">أطباؤنا المميّزون</h2>
          <p className="section-subtitle">
            فريق من أمهر الأطباء النفسيين المعتمدين لضمان أفضل رعاية نفسية
          </p>
        </motion.div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {featuredDoctors.map((doctor, index) => (
            <motion.div
              key={doctor.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="card overflow-hidden group"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={doctor.image_url || 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop'}
                  alt={doctor.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute bottom-4 right-4 text-white">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-[var(--accent)] fill-current" />
                    <span className="font-bold">{doctor.rating.toFixed(1)}</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Cairo' }}>
                  {doctor.name}
                </h3>
                <p className="text-[var(--primary)] font-medium mb-3">
                  {doctor.specialty}
                </p>
                <p className="text-[var(--text-secondary)] text-sm mb-4 line-clamp-2">
                  {doctor.bio}
                </p>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="text-sm text-[var(--text-secondary)]">
                    <span className="font-bold text-[var(--text-primary)]">{doctor.experience_years}</span> سنة خبرة
                  </div>
                  <div className="text-sm font-bold text-[var(--primary)]">
                    {doctor.consultation_price} $
                  </div>
                </div>

                <Link
                  to={`/booking?doctor=${doctor.id}`}
                  className="btn-primary w-full text-center mt-4 flex items-center justify-center gap-2"
                >
                  <Calendar className="w-5 h-5 flip-rtl" />
                  احجز استشارة
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link to="/doctors" className="btn-secondary inline-flex items-center gap-2">
            عرض جميع الأطباء
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedDoctors;