import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Pill,
  Calendar,
  MessageSquare,
  Settings,
  ChevronRight,
  LogOut,
  Menu,
  X
} from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, label: 'لوحة الإحصائيات', path: '/admin' },
  { icon: Users, label: 'إدارة الأطباء', path: '/admin/doctors' },
  { icon: Pill, label: 'إدارة الأدوية', path: '/admin/medications' },
  { icon: Calendar, label: 'طلبات الحجز', path: '/admin/bookings' },
  { icon: MessageSquare, label: 'الرسائل', path: '/admin/contacts' },
  { icon: Settings, label: 'الإعدادات', path: '/admin/settings' }
];

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout = ({ children }: AdminLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[var(--background)]">
      {/* Top Header */}
      <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-40">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 text-gray-600"
            >
              {sidebarOpen ? <X /> : <Menu />}
            </button>
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[var(--primary)] to-[var(--primary-light)] flex items-center justify-center">
                <span className="text-white font-bold" style={{ fontFamily: 'Cairo' }}>إ</span>
              </div>
              <span className="font-bold text-lg">إسكنير - لوحة التحكم</span>
            </Link>
          </div>
          <Link
            to="/"
            className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-[var(--primary)]"
          >
            <LogOut className="w-5 h-5 flip-rtl" />
            <span>العودة للموقع</span>
          </Link>
        </div>
      </header>

      {/* Sidebar */}
      <aside
        className={`fixed top-16 right-0 w-64 h-[calc(100vh-4rem)] bg-white shadow-lg transform transition-transform lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:block`}
      >
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                location.pathname === item.path
                  ? 'bg-[var(--primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
              {location.pathname === item.path && (
                <ChevronRight className="w-4 h-4 mr-auto flip-rtl" />
              )}
            </Link>
          ))}
        </nav>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="pt-16 lg:pr-64">
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
};

export default AdminLayout;