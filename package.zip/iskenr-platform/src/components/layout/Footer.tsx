import { Mail, Phone, Clock, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[var(--text-primary)] text-white pt-16 pb-8" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* About */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--accent)] to-[var(--secondary)] flex items-center justify-center">
                <span className="text-white font-bold text-xl" style={{ fontFamily: 'Cairo' }}>إ</span>
              </div>
              <div>
                <h3 className="text-xl font-bold" style={{ fontFamily: 'Cairo' }}>إسكنير</h3>
                <p className="text-sm text-gray-400">الطب النفسي الرقمي</p>
              </div>
            </div>
            <p className="text-gray-400 leading-relaxed">
              نقدم خدمات استشارات نفسية متكاملة باستخدام أحدث التقنيات، مع ضمان السرية التامة والاحترافية.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6" style={{ fontFamily: 'Cairo' }}>روابط سريعة</h4>
            <ul className="space-y-3">
              <li><a href="/" className="text-gray-400 hover:text-white transition-colors">الرئيسية</a></li>
              <li><a href="/services" className="text-gray-400 hover:text-white transition-colors">خدماتنا</a></li>
              <li><a href="/doctors" className="text-gray-400 hover:text-white transition-colors">أطباؤنا</a></li>
              <li><a href="/medications" className="text-gray-400 hover:text-white transition-colors">الأدوية</a></li>
              <li><a href="/#contact" className="text-gray-400 hover:text-white transition-colors">تواصل معنا</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold mb-6" style={{ fontFamily: 'Cairo' }}>خدماتنا</h4>
            <ul className="space-y-3">
              <li><span className="text-gray-400">الاستشارات الفردية</span></li>
              <li><span className="text-gray-400">الإرشاد الأسري والزوجي</span></li>
              <li><span className="text-gray-400">العلاج السلوكي المعرفي</span></li>
              <li><span className="text-gray-400">الدعم عن بُعد</span></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6" style={{ fontFamily: 'Cairo' }}>تواصل معنا</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[var(--accent)] flip-rtl" />
                <a href="mailto:haydariiskenr500@gmail.com" className="text-gray-400 hover:text-white transition-colors">
                  haydariiskenr500@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[var(--accent)] flip-rtl" />
                <a href="tel:+919515788653" className="text-gray-400 hover:text-white transition-colors">
                  +919515788653
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[var(--accent)] flip-rtl" />
                <span className="text-gray-400">متاحون على مدار الساعة</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © {currentYear} جميع الحقوق محفوظة - إسكنير
            </p>
            <p className="text-gray-500 text-sm">
              صنع بواسطة MiniMax Agent
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;