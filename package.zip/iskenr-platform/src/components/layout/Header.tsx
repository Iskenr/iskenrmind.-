import { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'الرئيسية', path: '/' },
    { name: 'خدماتنا', path: '/services' },
    { name: 'أطباؤنا', path: '/doctors' },
    { name: 'الأدوية', path: '/medications' },
    { name: 'تواصل معنا', path: '/#contact' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg'
          : 'bg-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--primary)] to-[var(--primary-light)] flex items-center justify-center">
              <span className="text-white font-bold text-xl" style={{ fontFamily: 'Cairo' }}>إ</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-[var(--text-primary)]" style={{ fontFamily: 'Cairo' }}>
                إسكنير
              </h1>
              <p className="text-xs text-[var(--text-secondary)]">الطب النفسي الرقمي</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-[var(--text-secondary)] hover:text-[var(--primary)] font-medium transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <a
              href="tel:+919515788653"
              className="hidden sm:flex items-center gap-2 text-[var(--primary)] font-medium"
            >
              <Phone className="w-5 h-5 flip-rtl" />
              <span>+919515788653</span>
            </a>
            <Link
              to="/booking"
              className="btn-primary hidden sm:inline-flex"
            >
              احجز الآن
            </Link>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-[var(--text-primary)]"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${
          isMenuOpen ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <div className="bg-white border-t px-4 py-6 space-y-4">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsMenuOpen(false)}
              className="block text-[var(--text-secondary)] hover:text-[var(--primary)] font-medium py-2"
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/booking"
            onClick={() => setIsMenuOpen(false)}
            className="btn-primary w-full text-center block"
          >
            احجز الآن
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;