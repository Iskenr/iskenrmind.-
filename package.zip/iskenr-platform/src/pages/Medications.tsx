import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, AlertCircle } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { supabase } from '../lib/supabase';
import type { Medication } from '../types';

const Medications = () => {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const fetchMedications = async () => {
      try {
        const { data, error } = await supabase
          .from('medications')
          .select('*')
          .eq('is_active', true);

        if (error) throw error;
        setMedications(data || []);
      } catch (error) {
        console.error('Error fetching medications:', error);
        // Use mock data
        setMedications([
          {
            id: '1',
            name: 'سيرترالين',
            generic_name: 'Sertraline',
            active_ingredient: 'سيرترالين هيدروكلوريد',
            indications: 'علاج الاكتئاب، اضطرابات القلق، اضطراب الوسواس القهري',
            dosage: '50 مجم - 200 مجم يومياً',
            side_effects: 'غثيان، أرق، صداع، جفاف الفم',
            image_url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=300&fit=crop',
            category: 'مضادات الاكتئاب',
            is_active: true
          },
          {
            id: '2',
            name: 'إسيتالوبرام',
            generic_name: 'Escitalopram',
            active_ingredient: 'إسيتالوبرام أكسالات',
            indications: 'علاج الاكتئاب الكبير، اضطرابات القلق العام',
            dosage: '10 مجم - 20 مجم يومياً',
            side_effects: 'غثيان، تعرق، إرهاق',
            image_url: 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=400&h=300&fit=crop',
            category: 'مضادات الاكتئاب',
            is_active: true
          },
          {
            id: '3',
            name: 'لورازيبام',
            generic_name: 'Lorazepam',
            active_ingredient: 'لورازيبام',
            indications: 'علاج اضطرابات القلق، الأرق، التشنجات',
            dosage: '0.5 مجم - 4 مجم يومياً',
            side_effects: 'نعاس، دوخة، ضعف العضلات',
            image_url: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=400&h=300&fit=crop',
            category: 'مضادات القلق',
            is_active: true
          },
          {
            id: '4',
            name: 'أريبيبرازول',
            generic_name: 'Aripiprazole',
            active_ingredient: 'أريبيبرازول',
            indications: 'علاج الفصام، اضطراب ثنائي القطب، اكتئاب',
            dosage: '2 مجم - 30 مجم يومياً',
            side_effects: 'صداع، غثيان، أرق',
            image_url: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=300&fit=crop',
            category: 'مضادات الذهان',
            is_active: true
          },
          {
            id: '5',
            name: 'بوبروبيون',
            generic_name: 'Bupropion',
            active_ingredient: 'هيدروكلوريد بوبروبيون',
            indications: 'علاج الاكتئاب، الإقلاع عن التدخين',
            dosage: '150 مجم - 300 مجم يومياً',
            side_effects: 'أرق، جفاف الفم، صداع',
            image_url: 'https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?w=400&h=300&fit=crop',
            category: 'مضادات الاكتئاب',
            is_active: true
          },
          {
            id: '6',
            name: 'برازولام',
            generic_name: 'Alprazolam',
            active_ingredient: 'برازولام',
            indications: 'علاج اضطرابات القلق، نوبات الهلع',
            dosage: '0.25 مجم - 2 مجم يومياً',
            side_effects: 'نعاس، ارتباك، ضعف التنسيق',
            image_url: 'https://images.unsplash.com/photo-1584305573924-48e4b5d1a84d?w=400&h=300&fit=crop',
            category: 'مضادات القلق',
            is_active: true
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchMedications();
  }, []);

  const categories = ['all', ...new Set(medications.map(m => m.category))];

  const filteredMedications = medications.filter(med => {
    const matchesSearch = med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      med.generic_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || med.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-[var(--primary)]/5 to-[var(--primary-light)]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            الأدوية النفسية
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-[var(--text-secondary)] max-w-2xl mx-auto"
          >
            معلومات شاملة عن الأدوية النفسية الشائعة واستخداماتها
          </motion.p>
        </div>
      </section>

      {/* Disclaimer */}
      <div className="bg-[var(--accent)]/10 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-[var(--accent)] shrink-0" />
          <p className="text-sm text-[var(--text-secondary)]">
            هذه المعلومات للأغراض التعليمية فقط ولا تُغني عن استشارة الطبيب المختص. لا تتناول أي دواء دون إشراف طبي.
          </p>
        </div>
      </div>

      {/* Filters */}
      <section className="py-8 bg-white border-b sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 flip-rtl" />
              <input
                type="text"
                placeholder="ابحث عن دواء..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)]"
              />
            </div>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full md:w-64 px-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] appearance-none bg-white"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category === 'all' ? 'جميع الفئات' : category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* Medications Grid */}
      <section className="py-16 flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center py-20">
              <div className="spinner w-12 h-12" />
            </div>
          ) : filteredMedications.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-[var(--text-secondary)] text-lg">لم يتم العثور على أدوية</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredMedications.map((medication, index) => (
                <motion.div
                  key={medication.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="card overflow-hidden"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={medication.image_url}
                      alt={medication.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 rounded-full text-sm font-medium">
                        {medication.category}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-1" style={{ fontFamily: 'Cairo' }}>
                      {medication.name}
                    </h3>
                    <p className="text-[var(--text-secondary)] text-sm mb-4">
                      {medication.generic_name}
                    </p>

                    <div className="space-y-3 mb-4">
                      <div>
                        <span className="text-sm font-medium text-[var(--text-primary)]">المادة الفعالة:</span>
                        <p className="text-sm text-[var(--text-secondary)]">{medication.active_ingredient}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-[var(--text-primary)]">دواعي الاستعمال:</span>
                        <p className="text-sm text-[var(--text-secondary)] line-clamp-2">{medication.indications}</p>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-100">
                      <p className="text-sm">
                        <span className="font-medium text-[var(--text-primary)]">الجرعة:</span>
                        <span className="text-[var(--text-secondary)] mr-2">{medication.dosage}</span>
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Medications;