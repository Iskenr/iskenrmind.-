import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Pill, Calendar, MessageSquare, TrendingUp, Clock } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';

interface Stats {
  doctors: number;
  medications: number;
  bookings: number;
  contacts: number;
}

const AdminDashboard = () => {
  const [stats, setStats] = useState<Stats>({
    doctors: 6,
    medications: 12,
    bookings: 45,
    contacts: 18
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setLoading(false), 500);
  }, []);

  const statCards = [
    { label: 'الأطباء', value: stats.doctors, icon: Users, color: 'from-blue-500 to-blue-600' },
    { label: 'الأدوية', value: stats.medications, icon: Pill, color: 'from-green-500 to-green-600' },
    { label: 'الحجوزات', value: stats.bookings, icon: Calendar, color: 'from-purple-500 to-purple-600' },
    { label: 'الرسائل', value: stats.contacts, icon: MessageSquare, color: 'from-orange-500 to-orange-600' }
  ];

  const recentBookings = [
    { id: '1', patient: 'أحمد محمد', doctor: 'د. حيدر إسكنير', type: 'فيديو', status: 'pending', date: '2025-01-15' },
    { id: '2', patient: 'سارة علي', doctor: 'د. سارة الأحمد', type: 'صوت', status: 'confirmed', date: '2025-01-14' },
    { id: '3', patient: 'خالد عمر', doctor: 'د. محمد العلي', type: 'رسائل', status: 'completed', date: '2025-01-13' },
    { id: '4', patient: 'نورة أحمد', doctor: 'د. حيدر إسكنير', type: 'فيديو', status: 'pending', date: '2025-01-12' }
  ];

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-700',
    confirmed: 'bg-blue-100 text-blue-700',
    completed: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700'
  };

  const statusLabels: Record<string, string> = {
    pending: 'في الانتظار',
    confirmed: 'مؤكد',
    completed: 'مكتمل',
    cancelled: 'ملغي'
  };

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold">لوحة الإحصائيات</h1>
        <p className="text-[var(--text-secondary)]">مرحباً بك في لوحة تحكم إسكنير</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--text-secondary)] mb-1">{stat.label}</p>
                <p className="text-3xl font-bold">{loading ? '-' : stat.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Bookings */}
        <div className="card">
          <div className="p-6 border-b">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[var(--primary)]" />
              آخر الحجوزات
            </h2>
          </div>
          <div className="divide-y">
            {recentBookings.map((booking) => (
              <div key={booking.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium">{booking.patient}</p>
                  <p className="text-sm text-[var(--text-secondary)]">
                    {booking.doctor} - {booking.type}
                  </p>
                </div>
                <div className="text-left">
                  <span className={`px-3 py-1 rounded-full text-sm ${statusColors[booking.status]}`}>
                    {statusLabels[booking.status]}
                  </span>
                  <p className="text-xs text-[var(--text-secondary)] mt-1">{booking.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="card p-6">
          <h2 className="text-lg font-bold mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[var(--primary)]" />
            إحصائيات سريعة
          </h2>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">معدل إكمال الحجوزات</span>
                <span className="font-bold">85%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[var(--success)] rounded-full w-[85%]" />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">رضا العملاء</span>
                <span className="font-bold">92%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[var(--primary)] rounded-full w-[92%]" />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">متوسط وقت الاستجابة</span>
                <span className="font-bold">2 ساعة</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[var(--accent)] rounded-full w-[70%]" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;