import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Edit2, Trash2, Search, X } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import { supabase } from '../../lib/supabase';
import type { Medication } from '../../types';

const medicationSchema = z.object({
  name: z.string().min(2, 'الاسم مطلوب'),
  generic_name: z.string().min(2, 'الاسم التجاري مطلوب'),
  active_ingredient: z.string().min(2, 'المادة الفعالة مطلوبة'),
  indications: z.string().min(10, 'دواعي الاستعمال مطلوبة'),
  dosage: z.string().min(2, 'الجرعة مطلوبة'),
  side_effects: z.string().optional(),
  image_url: z.string().url('رابط الصورة غير صالح').or(z.string().length(0)),
  category: z.string().min(2, 'الفئة مطلوبة'),
  is_active: z.boolean()
});

type MedicationFormData = z.infer<typeof medicationSchema>;

const AdminMedications = () => {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMedication, setEditingMedication] = useState<Medication | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm<MedicationFormData>({
    resolver: zodResolver(medicationSchema),
    defaultValues: {
      is_active: true
    }
  });

  useEffect(() => {
    fetchMedications();
  }, []);

  const fetchMedications = async () => {
    try {
      const { data } = await supabase
        .from('medications')
        .select('*')
        .order('created_at', { ascending: false });
      setMedications(data || []);
    } catch (error) {
      setMedications([
        {
          id: '1',
          name: 'سيرترالين',
          generic_name: 'Sertraline',
          active_ingredient: 'سيرترالين هيدروكلوريد',
          indications: 'علاج الاكتئاب، اضطرابات القلق',
          dosage: '50-200 مجم يومياً',
          side_effects: 'غثيان، أرق',
          image_url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=300&fit=crop',
          category: 'مضادات الاكتئاب',
          is_active: true
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: MedicationFormData) => {
    try {
      if (editingMedication) {
        const { error } = await supabase
          .from('medications')
          .update(data)
          .eq('id', editingMedication.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('medications').insert([data]);
        if (error) throw error;
      }
      await fetchMedications();
      closeModal();
    } catch (error) {
      console.error('Error saving medication:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الدواء؟')) return;
    try {
      const { error } = await supabase.from('medications').delete().eq('id', id);
      if (error) throw error;
      await fetchMedications();
    } catch (error) {
      console.error('Error deleting medication:', error);
    }
  };

  const openModal = (medication?: Medication) => {
    if (medication) {
      setEditingMedication(medication);
      reset(medication);
    } else {
      setEditingMedication(null);
      reset({
        name: '',
        generic_name: '',
        active_ingredient: '',
        indications: '',
        dosage: '',
        side_effects: '',
        image_url: '',
        category: '',
        is_active: true
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingMedication(null);
    reset();
  };

  const filteredMedications = medications.filter(med =>
    med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    med.generic_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">إدارة الأدوية</h1>
          <p className="text-[var(--text-secondary)]">إضافة وتعديل وحذف الأدوية</p>
        </div>
        <button onClick={() => openModal()} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          إضافة دواء جديد
        </button>
      </div>

      {/* Search */}
      <div className="card p-4 mb-6">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 flip-rtl" />
          <input
            type="text"
            placeholder="ابحث عن دواء..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)]"
          />
        </div>
      </div>

      {/* Medications Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full flex justify-center py-20">
            <div className="spinner w-12 h-12" />
          </div>
        ) : filteredMedications.length === 0 ? (
          <div className="col-span-full text-center py-20">
            <p className="text-[var(--text-secondary)]">لا يوجد أدوية</p>
          </div>
        ) : (
          filteredMedications.map((medication) => (
            <motion.div
              key={medication.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="card overflow-hidden"
            >
              <div className="relative h-40">
                <img
                  src={medication.image_url}
                  alt={medication.name}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-4 left-4 px-3 py-1 bg-white/90 rounded-full text-sm">
                  {medication.category}
                </span>
                <div className="absolute top-4 right-4 flex gap-2">
                  <button
                    onClick={() => openModal(medication)}
                    className="p-2 bg-white rounded-lg shadow hover:bg-gray-100"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(medication.id)}
                    className="p-2 bg-white rounded-lg shadow hover:bg-red-50 text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">{medication.name}</h3>
                <p className="text-sm text-[var(--text-secondary)] mb-2">{medication.generic_name}</p>
                <p className="text-sm text-[var(--text-secondary)] line-clamp-2">{medication.indications}</p>
                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <span className="text-sm font-medium">{medication.dosage}</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    medication.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {medication.is_active ? 'نشط' : 'غير نشط'}
                  </span>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="modal-overlay" onClick={closeModal}>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="modal-content w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-bold">
                {editingMedication ? 'تعديل الدواء' : 'إضافة دواء جديد'}
              </h2>
              <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">الاسم التجاري</label>
                  <input
                    {...register('name')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.name && <p className="text-[var(--error)] text-sm mt-1">{errors.name.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">الاسم العام</label>
                  <input
                    {...register('generic_name')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.generic_name && <p className="text-[var(--error)] text-sm mt-1">{errors.generic_name.message}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">المادة الفعالة</label>
                <input
                  {...register('active_ingredient')}
                  className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                />
                {errors.active_ingredient && <p className="text-[var(--error)] text-sm mt-1">{errors.active_ingredient.message}</p>}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">الفئة</label>
                  <input
                    {...register('category')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.category && <p className="text-[var(--error)] text-sm mt-1">{errors.category.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">الجرعة</label>
                  <input
                    {...register('dosage')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.dosage && <p className="text-[var(--error)] text-sm mt-1">{errors.dosage.message}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">دواعي الاستعمال</label>
                <textarea
                  {...register('indications')}
                  rows={3}
                  className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)] resize-none"
                />
                {errors.indications && <p className="text-[var(--error)] text-sm mt-1">{errors.indications.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">الأعراض الجانبية (اختياري)</label>
                <textarea
                  {...register('side_effects')}
                  rows={2}
                  className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)] resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">رابط الصورة</label>
                <input
                  {...register('image_url')}
                  className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  placeholder="https://..."
                />
                {errors.image_url && <p className="text-[var(--error)] text-sm mt-1">{errors.image_url.message}</p>}
              </div>

              <div className="flex items-center gap-2">
                <input type="checkbox" {...register('is_active')} id="is_active" className="w-5 h-5" />
                <label htmlFor="is_active" className="text-sm">دواء نشط</label>
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={closeModal} className="btn-secondary flex-1">
                  إلغاء
                </button>
                <button type="submit" disabled={isSubmitting} className="btn-primary flex-1 flex items-center justify-center gap-2">
                  {isSubmitting ? <span className="spinner" /> : 'حفظ'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminMedications;