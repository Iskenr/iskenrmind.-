import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Mail, Phone, Check, X, Eye } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';

interface Booking {
  id: string;
  patient_name: string;
  patient_email: string;
  patient_phone: string;
  doctor_name: string;
  session_type: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  created_at: string;
  notes: string;
}

const AdminBookings = () => {
  const [bookings] = useState<Booking[]>([
    { id: '1', patient_name: 'أحمد محمد', patient_email: 'ahmed@email.com', patient_phone: '+966501234567', doctor_name: 'د. حيدر إسكنير', session_type: 'فيديو', status: 'pending', created_at: '2025-01-15', notes: 'أرغب في مناقشة مشكلتي المتعلقة بالقلق' },
    { id: '2', patient_name: 'سارة علي', patient_email: 'sara@email.com', patient_phone: '+966507654321', doctor_name: 'د. سارة الأحمد', session_type: 'صوت', status: 'confirmed', created_at: '2025-01-14', notes: '' },
    { id: '3', patient_name: 'خالد عمر', patient_email: 'khaled@email.com', patient_phone: '+966509876543', doctor_name: 'د. محمد العلي', session_type: 'رسائل', status: 'completed', created_at: '2025-01-13', notes: 'متابعة بعد الجلسة الأولى' },
    { id: '4', patient_name: 'نورة أحمد', patient_email: 'noura@email.com', patient_phone: '+966501112223', doctor_name: 'د. حيدر إسكنير', session_type: 'فيديو', status: 'pending', created_at: '2025-01-12', notes: '' },
    { id: '5', patient_name: 'فهد السالم', patient_email: 'fahad@email.com', patient_phone: '+966503334445', doctor_name: 'د. نورة السعيد', session_type: 'فيديو', status: 'cancelled', created_at: '2025-01-10', notes: 'تم الإلغاء من قبل العميل' }
  ]);

  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);

  const statusConfig: Record<string, { color: string; label: string }> = {
    pending: { color: 'bg-yellow-100 text-yellow-700', label: 'في الانتظار' },
    confirmed: { color: 'bg-blue-100 text-blue-700', label: 'مؤكد' },
    completed: { color: 'bg-green-100 text-green-700', label: 'مكتمل' },
    cancelled: { color: 'bg-red-100 text-red-700', label: 'ملغي' }
  };

  const sessionIcons: Record<string, JSX.Element> = {
    'فيديو': <Calendar className="w-4 h-4" />,
    'صوت': <Phone className="w-4 h-4" />,
    'رسائل': <Mail className="w-4 h-4" />
  };

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold">إدارة الحجوزات</h1>
        <p className="text-[var(--text-secondary)]">عرض وإدارة طلبات الحجز</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {Object.entries(statusConfig).map(([key, config]) => {
          const count = bookings.filter(b => b.status === key).length;
          return (
            <div key={key} className="card p-4 text-center">
              <span className={`inline-block px-3 py-1 rounded-full text-sm ${config.color} mb-2`}>
                {config.label}
              </span>
              <p className="text-2xl font-bold">{count}</p>
            </div>
          );
        })}
      </div>

      {/* Bookings Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">المريض</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">الطبيب</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">نوع الجلسة</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">الحالة</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">التاريخ</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-[var(--text-secondary)]">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {bookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-medium">{booking.patient_name}</p>
                      <p className="text-sm text-[var(--text-secondary)]">{booking.patient_email}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-[var(--text-secondary)]">{booking.doctor_name}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                      {sessionIcons[booking.session_type]}
                      <span>{booking.session_type}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm ${statusConfig[booking.status].color}`}>
                      {statusConfig[booking.status].label}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-[var(--text-secondary)]">{booking.created_at}</td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedBooking(booking)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Booking Details Modal */}
      {selectedBooking && (
        <div className="modal-overlay" onClick={() => setSelectedBooking(null)}>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="modal-content w-full max-w-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-bold">تفاصيل الحجز</h2>
              <button onClick={() => setSelectedBooking(null)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">اسم المريض</p>
                  <p className="font-medium">{selectedBooking.patient_name}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">البريد الإلكتروني</p>
                  <p className="font-medium">{selectedBooking.patient_email}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">رقم الهاتف</p>
                  <p className="font-medium">{selectedBooking.patient_phone}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">الطبيب</p>
                  <p className="font-medium">{selectedBooking.doctor_name}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">نوع الجلسة</p>
                  <p className="font-medium">{selectedBooking.session_type}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">الحالة</p>
                  <span className={`px-3 py-1 rounded-full text-sm ${statusConfig[selectedBooking.status].color}`}>
                    {statusConfig[selectedBooking.status].label}
                  </span>
                </div>
              </div>
              {selectedBooking.notes && (
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">ملاحظات</p>
                  <p className="mt-1 p-3 bg-gray-50 rounded-lg">{selectedBooking.notes}</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminBookings;