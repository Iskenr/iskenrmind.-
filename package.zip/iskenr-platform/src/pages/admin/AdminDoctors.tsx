import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Edit2, Trash2, Search, X, Upload } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import { supabase } from '../../lib/supabase';
import type { Doctor } from '../../types';

const doctorSchema = z.object({
  name: z.string().min(2, 'الاسم مطلوب'),
  specialty: z.string().min(2, 'التخصص مطلوب'),
  bio: z.string().min(10, 'النبذة التعريفية مطلوبة'),
  experience_years: z.number().min(0, 'سنوات الخبرة يجب أن تكون رقم موجب'),
  rating: z.number().min(1).max(5),
  consultation_price: z.number().min(0),
  image_url: z.string().url('رابط الصورة غير صالح').or(z.string().length(0)),
  is_active: z.boolean()
});

type DoctorFormData = z.infer<typeof doctorSchema>;

const AdminDoctors = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm<DoctorFormData>({
    resolver: zodResolver(doctorSchema),
    defaultValues: {
      is_active: true,
      rating: 4.5,
      experience_years: 5,
      consultation_price: 100
    }
  });

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const { data } = await supabase
        .from('doctors')
        .select('*')
        .order('created_at', { ascending: false });
      setDoctors(data || []);
    } catch (error) {
      // Mock data
      setDoctors([
        {
          id: '1',
          name: 'د. حيدر إسكنير',
          specialty: 'طب نفسي سريري',
          bio: 'استشاري نفسي معتمد بخبرة 15 عاماً في علاج الاضطرابات النفسية المختلفة',
          experience_years: 15,
          rating: 4.9,
          consultation_price: 100,
          image_url: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
          is_active: true
        },
        {
          id: '2',
          name: 'د. سارة الأحمد',
          specialty: 'إرشاد نفسي',
          bio: 'متخصصة في الإرشاد الأسري والزوجي مع خبرة 10 سنوات',
          experience_years: 10,
          rating: 4.8,
          consultation_price: 80,
          image_url: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
          is_active: true
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: DoctorFormData) => {
    try {
      if (editingDoctor) {
        // Update existing doctor
        const { error } = await supabase
          .from('doctors')
          .update(data)
          .eq('id', editingDoctor.id);
        if (error) throw error;
      } else {
        // Create new doctor
        const { error } = await supabase.from('doctors').insert([data]);
        if (error) throw error;
      }
      await fetchDoctors();
      closeModal();
    } catch (error) {
      console.error('Error saving doctor:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الطبيب؟')) return;
    try {
      const { error } = await supabase.from('doctors').delete().eq('id', id);
      if (error) throw error;
      await fetchDoctors();
    } catch (error) {
      console.error('Error deleting doctor:', error);
    }
  };

  const openModal = (doctor?: Doctor) => {
    if (doctor) {
      setEditingDoctor(doctor);
      reset(doctor);
    } else {
      setEditingDoctor(null);
      reset({
        name: '',
        specialty: '',
        bio: '',
        experience_years: 5,
        rating: 4.5,
        consultation_price: 100,
        image_url: '',
        is_active: true
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingDoctor(null);
    reset();
  };

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">إدارة الأطباء</h1>
          <p className="text-[var(--text-secondary)]">إضافة وتعديل وحذف الأطباء</p>
        </div>
        <button onClick={() => openModal()} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          إضافة طبيب جديد
        </button>
      </div>

      {/* Search */}
      <div className="card p-4 mb-6">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 flip-rtl" />
          <input
            type="text"
            placeholder="ابحث عن طبيب..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)]"
          />
        </div>
      </div>

      {/* Doctors Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="spinner w-12 h-12" />
          </div>
        ) : filteredDoctors.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-[var(--text-secondary)]">لا يوجد أطباء</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">الطبيب</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">التخصص</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">الخبرة</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">السعر</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-[var(--text-secondary)]">الحالة</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-[var(--text-secondary)]">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredDoctors.map((doctor) => (
                <tr key={doctor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={doctor.image_url}
                        alt={doctor.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <p className="font-medium">{doctor.name}</p>
                        <p className="text-sm text-[var(--text-secondary)]">{doctor.rating} ★</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-[var(--text-secondary)]">{doctor.specialty}</td>
                  <td className="px-6 py-4 text-[var(--text-secondary)]">{doctor.experience_years} سنة</td>
                  <td className="px-6 py-4 text-[var(--text-secondary)]">${doctor.consultation_price}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      doctor.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {doctor.is_active ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openModal(doctor)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(doctor.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="modal-overlay" onClick={closeModal}>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="modal-content w-full max-w-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-bold">
                {editingDoctor ? 'تعديل الطبيب' : 'إضافة طبيب جديد'}
              </h2>
              <button onClick={closeModal} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">الاسم</label>
                  <input
                    {...register('name')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.name && <p className="text-[var(--error)] text-sm mt-1">{errors.name.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">التخصص</label>
                  <input
                    {...register('specialty')}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                  {errors.specialty && <p className="text-[var(--error)] text-sm mt-1">{errors.specialty.message}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">النبذة التعريفية</label>
                <textarea
                  {...register('bio')}
                  rows={3}
                  className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)] resize-none"
                />
                {errors.bio && <p className="text-[var(--error)] text-sm mt-1">{errors.bio.message}</p>}
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">سنوات الخبرة</label>
                  <input
                    type="number"
                    {...register('experience_years', { valueAsNumber: true })}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">التقييم (1-5)</label>
                  <input
                    type="number"
                    step="0.1"
                    {...register('rating', { valueAsNumber: true })}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">سعر الاستشارة ($)</label>
                  <input
                    type="number"
                    {...register('consultation_price', { valueAsNumber: true })}
                    className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">رابط الصورة</label>
                <div className="flex gap-2">
                  <input
                    {...register('image_url')}
                    className="flex-1 px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                    placeholder="https://..."
                  />
                </div>
                {errors.image_url && <p className="text-[var(--error)] text-sm mt-1">{errors.image_url.message}</p>}
              </div>

              <div className="flex items-center gap-2">
                <input type="checkbox" {...register('is_active')} id="is_active" className="w-5 h-5" />
                <label htmlFor="is_active" className="text-sm">طبيب نشط</label>
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={closeModal} className="btn-secondary flex-1">
                  إلغاء
                </button>
                <button type="submit" disabled={isSubmitting} className="btn-primary flex-1 flex items-center justify-center gap-2">
                  {isSubmitting ? <span className="spinner" /> : 'حفظ'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AdminLayout>
  );
};

export default AdminDoctors;