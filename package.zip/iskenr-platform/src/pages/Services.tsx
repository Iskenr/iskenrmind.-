import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Brain, Users, Target, Video, ArrowRight, CheckCircle } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';

const services = [
  {
    icon: Brain,
    title: 'الاستشارات النفسية الفردية',
    description: 'نقدم جلسات مهنية متخصصة لمساعدة الأفراد على التعامل مع القلق، الاكتئاب، الضغوط اليومية، واضطرابات المزاج. نستخدم أساليب علمية مثبتة لتحقيق أفضل النتائج.',
    features: ['علاج القلق والاكتئاب', 'إدارة الضغوط النفسية', 'تحسين جودة النوم', 'بناء الثقة بالنفس', 'تطوير المهارات الاجتماعية'],
    image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600&h=400&fit=crop'
  },
  {
    icon: Users,
    title: 'الإرشاد الأسري والزوجي',
    description: 'نسعى لدعم العلاقات وتحسين التواصل داخل الأسرة. نقدم استشارات متخصصة للأزواج والأسر للتغلب على التحديات وتحقيق التفاهم المتبادل.',
    features: ['تحسين مهارات التواصل', 'حل النزاعات الزوجية', 'تقوية الروابط الأسرية', 'إرشاد ما قبل الزواج', 'التعامل مع ضغوط الأبوة'],
    image: 'https://images.unsplash.com/photo-1609220136736-443140cffec6?w=600&h=400&fit=crop'
  },
  {
    icon: Target,
    title: 'العلاج السلوكي المعرفي (CBT)',
    description: 'نستخدم تقنيات علمية فعّالة لتغيير الأنماط الفكرية والسلوكية السلبية. العلاج السلوكي المعرفي من أكثر الأساليب فعالية في علاج الاضطرابات النفسية.',
    features: ['تحليل وتعديل الأفكار السلبية', 'بناء أنماط تفكير صحية', 'حل المشكلات بفعالية', 'منع الانتكاسات', 'تطوير استراتيجيات التكيف'],
    image: 'https://images.unsplash.com/photo-1493836512294-502baa1986e2?w=600&h=400&fit=crop'
  },
  {
    icon: Video,
    title: 'الدعم النفسي عن بُعد',
    description: 'نوفر إمكانية الحصول على دعم نفسي متخصص من أي مكان عبر الإنترنت. اختر الطريقة المناسبة لك: جلسات فيديو مباشرة، مكالمات صوتية، أو رسائل خاصة.',
    features: ['جلسات فيديو مباشرة', 'مكالمات صوتية خاصة', 'محادثات نصية آمنة', 'مرونة في المواعيد', 'خصوصية تامة'],
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=400&fit=crop'
  }
];

const faqs = [
  { q: 'كيف أبدأ بالاستشارة؟', a: 'يمكنك حجز استشارة من خلال ملء نموذج التواصل أو الضغط على زر "احجز الآن" في الموقع. سنقوم بالتواصل معك لتأكيد الموعد.' },
  { q: 'هل الاستشارات سرية؟', a: 'نعم، نضمن السرية التامة لجميع الاستشارات. جميع المعلومات التي تشاركها معنا تبقى خاصة تماماً.' },
  { q: 'ما مدة الجلسة؟', a: 'تتراوح مدة الجلسة بين 45-60 دقيقة حسب نوع الاستشارة واحتياجاتك.' },
  { q: 'هل يمكنني تغيير نوع الجلسة؟', a: 'نعم، يمكنك اختيار نوع الجلسة المناسب لك: فيديو، صوت، أو رسائل. يمكنك أيضاً تغيير نوع الجلسة في أي وقت.' },
  { q: 'ما هي طرق الدفع؟', a: 'نقبل الدفع عبر التحويل البنكي وغيرها من الطرق. تفاصيل الدفع ستظهر عند تأكيد الحجز.' }
];

const Services = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-[var(--primary)]/5 to-[var(--primary-light)]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            خدماتنا النفسية
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-[var(--text-secondary)] max-w-2xl mx-auto"
          >
            نقدم مجموعة شاملة من الخدمات النفسية الاحترافية المصممة لتلبية احتياجاتك
          </motion.p>
        </div>
      </section>

      {/* Services Details */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`grid lg:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
              }`}
            >
              <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[var(--primary)]/10 to-[var(--primary-light)]/10 flex items-center justify-center mb-6">
                  <service.icon className="w-8 h-8 text-[var(--primary)]" />
                </div>
                <h2 className="text-3xl font-bold mb-4" style={{ fontFamily: 'Cairo' }}>
                  {service.title}
                </h2>
                <p className="text-[var(--text-secondary)] text-lg leading-relaxed mb-6">
                  {service.description}
                </p>
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-[var(--success)] flip-rtl" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/booking" className="btn-primary inline-flex items-center gap-2">
                  احجز الآن
                  <ArrowRight className="w-5 h-5 flip-rtl" />
                </Link>
              </div>
              <div className={`relative ${index % 2 === 1 ? 'lg:col-start-1' : ''}`}>
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full rounded-2xl shadow-xl"
                />
                <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-[var(--accent)]/20 rounded-full blur-2xl" />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-[var(--primary)] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-12">لماذا نحن؟</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: '🔒', title: 'السرية التامة', desc: 'نضمن حماية خصوصيتك' },
              { icon: '⭐', title: 'المهنية العالية', desc: 'فريق من خبراء معتمدين' },
              { icon: '🤝', title: 'الاحترام المتبادل', desc: 'نصلك بمهنية واحترام' },
              { icon: '⏰', title: 'متاحون دائماً', desc: 'دعم على مدار الساعة' }
            ].map((item) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-white/80">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">أسئلة شائعة</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card p-6"
              >
                <h3 className="font-bold text-lg mb-2">{faq.q}</h3>
                <p className="text-[var(--text-secondary)]">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[var(--background)]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">هل أنت مستعد للبدء؟</h2>
          <p className="text-[var(--text-secondary)] text-lg mb-8">
            لا تنتظر أكثر - احجز استشارتك الآن واتخذ الخطوة الأولى نحو حياة أفضل
          </p>
          <Link to="/booking" className="btn-primary inline-flex items-center gap-2 text-lg px-8 py-4">
            احجز استشارتك الآن
            <ArrowRight className="w-5 h-5 flip-rtl" />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Services;