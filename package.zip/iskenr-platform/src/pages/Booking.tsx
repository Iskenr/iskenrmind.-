import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Calendar, Video, Phone, MessageSquare, Check, ArrowRight, ArrowLeft } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { supabase } from '../lib/supabase';
import type { Doctor } from '../types';

const bookingSchema = z.object({
  doctor_id: z.string().min(1, 'اختر الطبيب'),
  session_type: z.enum(['video', 'voice', 'text']),
  patient_name: z.string().min(2, 'الاسم مطلوب'),
  patient_email: z.string().email('بريد إلكتروني غير صالح'),
  patient_phone: z.string().min(10, 'رقم الهاتف مطلوب'),
  notes: z.string().optional()
});

type BookingFormData = z.infer<typeof bookingSchema>;

const Booking = () => {
  const [step, setStep] = useState(1);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors }
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      session_type: 'video'
    }
  });

  const selectedDoctorId = watch('doctor_id');
  const selectedSessionType = watch('session_type');

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const { data } = await supabase
          .from('doctors')
          .select('*')
          .eq('is_active', true);
        setDoctors(data || []);
      } catch (error) {
        setDoctors([
          {
            id: '1',
            name: 'د. حيدر إسكنير',
            specialty: 'طب نفسي سريري',
            bio: 'استشاري نفسي معتمد',
            experience_years: 15,
            rating: 4.9,
            consultation_price: 100,
            image_url: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
            is_active: true
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  const selectedDoctor = doctors.find(d => d.id === selectedDoctorId);

  const onSubmit = async (data: BookingFormData) => {
    setSubmitting(true);
    try {
      // Here you would save to Supabase
      console.log('Booking data:', data);
      setBookingComplete(true);
    } catch (error) {
      console.error('Booking error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  if (bookingComplete) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-32 pb-16">
          <div className="max-w-2xl mx-auto px-4 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-24 h-24 bg-[var(--success)] rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Check className="w-12 h-12 text-white" />
            </motion.div>
            <h1 className="text-3xl font-bold mb-4">تم الحجز بنجاح!</h1>
            <p className="text-[var(--text-secondary)] mb-8">
              سنتواصل معك قريباً لتأكيد موعد الاستشارة
            </p>
            <a href="/" className="btn-primary inline-flex items-center gap-2">
              العودة للرئيسية
            </a>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-32 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">احجز استشارتك</h1>
            <p className="text-[var(--text-secondary)]">
              اختر الطبيب ونوع الجلسة المناسبة لك
            </p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-12">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    step >= s
                      ? 'bg-[var(--primary)] text-white'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-20 h-1 mx-2 ${
                      step > s ? 'bg-[var(--primary)]' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)} className="card p-8">
            {/* Step 1: Select Doctor */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-xl font-bold mb-6">اختر الطبيب</h2>
                <div className="grid md:grid-cols-2 gap-4 mb-8">
                  {doctors.map((doctor) => (
                    <label
                      key={doctor.id}
                      className={`card p-4 cursor-pointer transition-all ${
                        selectedDoctorId === doctor.id
                          ? 'border-[var(--primary)] ring-2 ring-[var(--primary)]/20'
                          : 'hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        {...register('doctor_id')}
                        value={doctor.id}
                        className="hidden"
                      />
                      <div className="flex items-center gap-4">
                        <img
                          src={doctor.image_url}
                          alt={doctor.name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div>
                          <h3 className="font-bold">{doctor.name}</h3>
                          <p className="text-sm text-[var(--text-secondary)]">{doctor.specialty}</p>
                          <p className="text-sm font-bold text-[var(--primary)]">{doctor.consultation_price}$</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
                {errors.doctor_id && (
                  <p className="text-[var(--error)] text-sm mb-4">{errors.doctor_id.message}</p>
                )}
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  disabled={!selectedDoctorId}
                  className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  التالي
                  <ArrowLeft className="w-5 h-5 mr-2 flip-rtl" />
                </button>
              </motion.div>
            )}

            {/* Step 2: Select Session Type */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-xl font-bold mb-6">اختر نوع الجلسة</h2>
                <div className="grid md:grid-cols-3 gap-4 mb-8">
                  {[
                    { value: 'video', label: 'فيديو', icon: Video, desc: 'جلسة فيديو مباشرة' },
                    { value: 'voice', label: 'صوت', icon: Phone, desc: 'مكالمة صوتية' },
                    { value: 'text', label: 'رسائل', icon: MessageSquare, desc: 'محادثة نصية' }
                  ].map((type) => (
                    <label
                      key={type.value}
                      className={`card p-6 cursor-pointer transition-all text-center ${
                        selectedSessionType === type.value
                          ? 'border-[var(--primary)] ring-2 ring-[var(--primary)]/20'
                          : 'hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        {...register('session_type')}
                        value={type.value}
                        className="hidden"
                      />
                      <type.icon className={`w-12 h-12 mx-auto mb-3 ${
                        selectedSessionType === type.value ? 'text-[var(--primary)]' : 'text-gray-400'
                      }`} />
                      <h3 className="font-bold mb-1">{type.label}</h3>
                      <p className="text-sm text-[var(--text-secondary)]">{type.desc}</p>
                    </label>
                  ))}
                </div>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="btn-secondary"
                  >
                    <ArrowRight className="w-5 h-5 ml-2 flip-rtl" />
                    السابق
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="btn-primary flex-1"
                  >
                    التالي
                    <ArrowLeft className="w-5 h-5 mr-2 flip-rtl" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* Step 3: Personal Info */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h2 className="text-xl font-bold mb-6">البيانات الشخصية</h2>
                <div className="space-y-4 mb-8">
                  <div>
                    <label className="block text-sm font-medium mb-2">الاسم</label>
                    <input
                      type="text"
                      {...register('patient_name')}
                      className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                      placeholder="أدخل اسمك الكامل"
                    />
                    {errors.patient_name && (
                      <p className="text-[var(--error)] text-sm mt-1">{errors.patient_name.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                    <input
                      type="email"
                      {...register('patient_email')}
                      className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                      placeholder="example@email.com"
                    />
                    {errors.patient_email && (
                      <p className="text-[var(--error)] text-sm mt-1">{errors.patient_email.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">رقم الهاتف</label>
                    <input
                      type="tel"
                      {...register('patient_phone')}
                      className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)]"
                      placeholder="+966 XX XXX XXXX"
                    />
                    {errors.patient_phone && (
                      <p className="text-[var(--error)] text-sm mt-1">{errors.patient_phone.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">ملاحظات (اختياري)</label>
                    <textarea
                      {...register('notes')}
                      rows={4}
                      className="w-full px-4 py-3 border rounded-lg focus:border-[var(--primary)] resize-none"
                      placeholder="أي ملاحظات إضافية..."
                    />
                  </div>
                </div>

                {/* Summary */}
                {selectedDoctor && (
                  <div className="bg-[var(--background)] rounded-lg p-4 mb-8">
                    <h3 className="font-bold mb-3">ملخص الحجز</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-[var(--text-secondary)]">الطبيب:</span>
                        <span className="mr-2 font-medium">{selectedDoctor.name}</span>
                      </div>
                      <div>
                        <span className="text-[var(--text-secondary)]">نوع الجلسة:</span>
                        <span className="mr-2 font-medium">
                          {selectedSessionType === 'video' ? 'فيديو' : selectedSessionType === 'voice' ? 'صوت' : 'رسائل'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[var(--text-secondary)]">السعر:</span>
                        <span className="mr-2 font-bold text-[var(--primary)]">{selectedDoctor.consultation_price}$</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="btn-secondary"
                  >
                    <ArrowRight className="w-5 h-5 ml-2 flip-rtl" />
                    السابق
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="btn-primary flex-1 flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <span className="spinner" />
                    ) : (
                      <>
                        تأكيد الحجز
                        <Check className="w-5 h-5 mr-2 flip-rtl" />
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Booking;