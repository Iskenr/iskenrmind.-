import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Star, Calendar, Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { supabase } from '../lib/supabase';
import type { Doctor } from '../types';

const Doctors = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const { data, error } = await supabase
          .from('doctors')
          .select('*')
          .eq('is_active', true);

        if (error) throw error;
        setDoctors(data || []);
      } catch (error) {
        console.error('Error fetching doctors:', error);
        // Use mock data
        setDoctors([
          {
            id: '1',
            name: 'د. حيدر إسكنير',
            specialty: 'طب نفسي سريري',
            bio: 'استشاري نفسي معتمد بخبرة 15 عاماً في علاج الاضطرابات النفسية المختلفة والقلق والاكتئاب',
            experience_years: 15,
            rating: 4.9,
            consultation_price: 100,
            image_url: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '2',
            name: 'د. سارة الأحمد',
            specialty: 'إرشاد نفسي',
            bio: 'متخصصة في الإرشاد الأسري والزوجي مع خبرة 10 سنوات في دعم العلاقات وتحسين التواصل',
            experience_years: 10,
            rating: 4.8,
            consultation_price: 80,
            image_url: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '3',
            name: 'د. محمد العلي',
            specialty: 'علاج سلوكي معرفي',
            bio: 'خبير في العلاج السلوكي المعرفي مع أكثر من 12 عاماً من الخبرة في تغيير الأنماط السلبية',
            experience_years: 12,
            rating: 4.7,
            consultation_price: 90,
            image_url: 'https://images.unsplash.com/photo-1537368910035-5e427473b4fa?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '4',
            name: 'د. نورة السعيد',
            specialty: 'طب نفسي.children',
            bio: 'متخصصة في الصحة النفسية للأطفال والمراهقين مع خبرة 8 سنوات',
            experience_years: 8,
            rating: 4.9,
            consultation_price: 85,
            image_url: 'https://images.unsplash.com/photo-1559839734-2b641ea7af1a?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '5',
            name: 'د. أحمد المحمد',
            specialty: 'علاج الإدمان',
            bio: 'متخصص في علاج الإدمان واضطرابات الاستخدام مع خبرة 11 عاماً',
            experience_years: 11,
            rating: 4.6,
            consultation_price: 95,
            image_url: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '6',
            name: 'د. فاطمة الزهراء',
            specialty: 'طب نفسي سريري',
            bio: 'استشارية في الطب النفسي السريري مع تركيز على علاج اضطرابات القلق والاكتئاب',
            experience_years: 9,
            rating: 4.8,
            consultation_price: 88,
            image_url: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=400&h=400&fit=crop',
            is_active: true
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  const specialties = ['all', ...new Set(doctors.map(d => d.specialty))];

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = selectedSpecialty === 'all' || doctor.specialty === selectedSpecialty;
    return matchesSearch && matchesSpecialty;
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-[var(--primary)]/5 to-[var(--primary-light)]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            أطباؤنا المعتمدون
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-[var(--text-secondary)] max-w-2xl mx-auto"
          >
            فريق من أمهر الأطباء النفسيين المعتمدين لضمان أفضل رعاية نفسية
          </motion.p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white border-b sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 flip-rtl" />
              <input
                type="text"
                placeholder="ابحث عن طبيب..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-12 pl-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)]"
              />
            </div>

            {/* Specialty Filter */}
            <div className="relative">
              <Filter className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 flip-rtl" />
              <select
                value={selectedSpecialty}
                onChange={(e) => setSelectedSpecialty(e.target.value)}
                className="w-full md:w-64 pr-10 pl-4 py-3 border border-gray-200 rounded-lg focus:border-[var(--primary)] appearance-none bg-white"
              >
                {specialties.map((specialty) => (
                  <option key={specialty} value={specialty}>
                    {specialty === 'all' ? 'جميع التخصصات' : specialty}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Doctors Grid */}
      <section className="py-16 flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center py-20">
              <div className="spinner w-12 h-12" />
            </div>
          ) : filteredDoctors.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-[var(--text-secondary)] text-lg">لم يتم العثور على أطباء</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredDoctors.map((doctor, index) => (
                <motion.div
                  key={doctor.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="card overflow-hidden group"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={doctor.image_url}
                      alt={doctor.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 right-4 text-white">
                      <div className="flex items-center gap-1">
                        <Star className="w-5 h-5 text-[var(--accent)] fill-current" />
                        <span className="font-bold">{doctor.rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Cairo' }}>
                      {doctor.name}
                    </h3>
                    <p className="text-[var(--primary)] font-medium mb-3">
                      {doctor.specialty}
                    </p>
                    <p className="text-[var(--text-secondary)] text-sm mb-4 line-clamp-2">
                      {doctor.bio}
                    </p>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className="text-sm text-[var(--text-secondary)]">
                        <span className="font-bold text-[var(--text-primary)]">{doctor.experience_years}</span> سنة خبرة
                      </div>
                      <div className="text-sm font-bold text-[var(--primary)]">
                        {doctor.consultation_price} $
                      </div>
                    </div>

                    <Link
                      to={`/booking?doctor=${doctor.id}`}
                      className="btn-primary w-full text-center mt-4 flex items-center justify-center gap-2"
                    >
                      <Calendar className="w-5 h-5 flip-rtl" />
                      احجز استشارة
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Doctors;