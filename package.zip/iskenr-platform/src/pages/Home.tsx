import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Hero from '../components/sections/Hero';
import Services from '../components/sections/Services';
import FeaturedDoctors from '../components/sections/FeaturedDoctors';
import Contact from '../components/sections/Contact';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Doctor } from '../types';

const Home = () => {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const { data, error } = await supabase
          .from('doctors')
          .select('*')
          .eq('is_active', true)
          .limit(6);

        if (error) throw error;
        setDoctors(data || []);
      } catch (error) {
        console.error('Error fetching doctors:', error);
        // Use mock data for demo
        setDoctors([
          {
            id: '1',
            name: 'د. حيدر إسكنير',
            specialty: 'طب نفسي سريري',
            bio: 'استشاري نفسي معتمد بخبرة 15 عاماً في علاج الاضطرابات النفسية المختلفة',
            experience_years: 15,
            rating: 4.9,
            consultation_price: 100,
            image_url: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '2',
            name: 'د. سارة الأحمد',
            specialty: 'إرشاد نفسي',
            bio: 'متخصصة في الإرشاد الأسري والزوجي مع خبرة 10 سنوات',
            experience_years: 10,
            rating: 4.8,
            consultation_price: 80,
            image_url: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
            is_active: true
          },
          {
            id: '3',
            name: 'د. محمد العلي',
            specialty: 'علاج سلوكي معرفي',
            bio: 'خبير في العلاج السلوكي المعرفي مع أكثر من 12 عاماً من الخبرة',
            experience_years: 12,
            rating: 4.7,
            consultation_price: 90,
            image_url: 'https://images.unsplash.com/photo-1537368910035-5e427473b4fa?w=400&h=400&fit=crop',
            is_active: true
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Services />
        {!loading && doctors.length > 0 && <FeaturedDoctors doctors={doctors} />}
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Home;