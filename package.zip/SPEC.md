# منصة إسكنير للطب النفسي الرقمي - المواصفات التقنية

## 1. الرؤية والمفهوم

منصة **إسكنير** هي بيئة رقمية احترافية متكاملة للطب النفسي، تجمع بين سهولة الوصول وجودة الرعاية النفسية المتخصصة. تقدم المنصة تجربة آمنة ومريحة للمرضى للتواصل مع أطباء نفسيين معتمدين، مع لوحة تحكم إدارية متكاملة لإدارة الكادر الطبي والأدوية والمحتوى.

**الشخصية البصرية**: هادئة، احترافية، ثقة مطلقة - تصميم يعكس الأمان والراحة النفسية.

## 2. لغة التصميم

### الاتجاه الجمالي
تصميم **"الهدوء النفسي"** - يستلهم من مساحات العلاج النفسي الحديثة مع لمسات عربية أصيلة. يستخدام مساحات بيضاء واسعة، ألوان هادئة، وخطوط ناعمة تنقل رسالة الطمأنينة والاحترافية.

### لوحة الألوان
```
--primary: #4A7C59        /* أخضر الغابة - رمز السلام النفسي */
--primary-light: #6B9B7A  /* أخضر فاتح للتدرجات */
--secondary: #8B7355      /* بني دافئ - دفء إنساني */
--accent: #C9A86C         /* ذهبي - تميّز واحترافية */
--background: #FAFBF9     /* أبيض مائل للأخضر - نقاء */
--surface: #FFFFFF        /* أبيض للبطاقات */
--text-primary: #2D3B2D   /* أخضر داكن للنصوص */
--text-secondary: #5C6B5C /* رمادي أخضر للنصوص الثانوية */
--error: #C75D5D          /* أحمر هادئ للرسائل */
--success: #5D9C6D        /* أخضر للنجاح */
```

### الخطوط
- **العناوين**: Cairo (Google Fonts) - خط عربي حديث ومهني
- **النصوص**: Tajawal (Google Fonts) - سهل القراءة ومريح للعين
- **الأرقام**: Rubik - للبيانات والإحصائيات

### نظام المسافات
- Base unit: 8px
- Spacing scale: 4, 8, 12, 16, 24, 32, 48, 64, 96px
- Border radius: 8px (صغير), 16px (متوسط), 24px (كبير)
- Max content width: 1280px

### فلسفة الحركة
- **الانتقالات**: 300ms ease-out للتفاعلات السريعة
- **الظهور**: 500ms ease-out مع fade + translate-Y خفيف
- **التحميل**: نبض خفيف (pulse) يعكس الهدوء
- **Hover**: scale(1.02) مع ظل خفيف

### العناصر البصرية
- أيقونات: Lucide Icons - تصميم نظيف ومهني
- صور: Unsplash للصور الطبية/العلاجية
- زخارف: خطوط منحنية بسيطة كخلفيات

## 3. الهيكل والتخطيط

### الصفحات الرئيسية

#### 1. الصفحة الرئيسية (/)
```
├── Header (sticky)
│   ├── Logo
│   ├── Navigation
│   │   ├── الرئيسية
│   │   ├── خدماتنا
│   │   ├── أطباؤنا
│   │   ├── الأدوية
│   │   └── لوحة التحكم (admin only)
│   └── زر الحجز
├── Hero Section
│   ├── عنوان رئيسي مع تأثير gradient
│   ├── وصف مختصر
│   ├── زر CTA رئيسي
│   └── صورة/رسم توضيحي
├── Statistics Bar
│   ├── +1000 جلسة ناجحة
│   ├── +50 طبيب معتمد
│   └── +10000 مريض
├── Services Grid (4 خدمات رئيسية)
│   ├── الاستشارات الفردية
│   ├── الإرشاد الأسري والزوجي
│   ├── العلاج السلوكي المعرفي
│   └── الدعم عن بُعد
├── Featured Doctors Section
│   ├── عنوان القسم
│   └── 3 بطاقات أطباء مميزين
├── About Section
│   ├── صورة المستشار
│   ├── نبذة تعريفية
│   └── قيم المنصة
├── Understanding Mental Health
│   └── 3 مقالات/مقاطع تثقيفية
├── Contact Section
│   ├── نموذج تواصل
│   └── معلومات الاتصال
└── Footer
```

#### 2. صفحة الخدمات (/services)
```
├── Header
├── Hero داخلي
├── Grid الخدمات (detailed)
│   ├── صورة الخدمة
│   ├── عنوان
│   ├── وصف مفصل
│   └── زر احجز الآن
└── FAQ Section
```

#### 3. صفحة الأطباؤنا (/doctors)
```
├── Header
├── Hero داخلي
├── فلتر حسب التخصص
├── Grid بطاقات الأطباء
│   ├── صورة
│   ├── الاسم
│   ├── التخصص
│   ├── الخبرة
│   ├── التقييم (نجوم)
│   └── زر حجز
└── Pagination
```

#### 4. صفحة الأدوية (/medications)
```
├── Header
├── Hero داخلي
├── Search bar
├── Categories filter
├── Grid بطاقات الأدوية
│   ├── صورة الدواء
│   ├── الاسم
│   ├── المادة الفعالة
│   ├── دواعي الاستعمال
│   └── الجرعة
└── Disclaimer قانوني
```

#### 5. صفحة حجز الاستشارة (/booking)
```
├── Header
├── Step Wizard
│   ├── Step 1: اختيار الطبيب
│   ├── Step 2: نوع الجلسة
│   ├── Step 3: البيانات الشخصية
│   └── Step 4: تأكيد الحجز
└── Summary Panel
```

#### 6. لوحة التحكم (/admin) - محمية
```
├── Sidebar Navigation
│   ├── لوحة الإحصائيات
│   ├── إدارة الأطباء
│   ├── إدارة الأدوية
│   ├── طلبات الحجز
│   ├── الرسائل
│   └── الإعدادات
├── Dashboard Overview
│   ├── إحصائيات سريعة
│   ├── Recent bookings
│   └── Charts
├── Doctors Management
│   ├── List View
│   ├── Add/Edit Form
│   └── Image Upload
├── Medications Management
│   ├── List View
│   ├── Add/Edit Form
│   └── Image Upload
└── Bookings Management
    ├── List with filters
    ├── Status management
    └── Contact client
```

### استراتيجية الاستجابة
- **Desktop**: > 1024px - تخطيط كامل
- **Tablet**: 768px - 1024px - تكديس جزئي
- **Mobile**: < 768px - تكديس كامل، قائمة hamburger

## 4. الميزات والتفاعلات

### المصادقة (Authentication)
- **التسجيل**: بريد إلكتروني + كلمة مرور
- **تسجيل الدخول**: بريد إلكتروني + كلمة مرور
- **استعادة كلمة المرور**: عبر البريد الإلكتروني
- **حالة المستخدم**: logged out / logged in / admin

### حجز الاستشارات
```
Flow:
1. اختيار الطبيب → 2. اختيار نوع الجلسة → 3. ملء البيانات → 4. تأكيد
- Doctor selection: عرض بطاقات مع صور وتقييم
- Session type: فيديو / صوت / رسائل
- Form: اسم، هاتف، بريد، ملاحظات
- Confirmation: رسالة نجاح + إرسال بريد
- Status: pending → confirmed → completed / cancelled
```

### إدارة الأطباء (Admin)
```
CRUD Operations:
- Create: نموذج إضافة مع رفع صورة
- Read: جدول مع صور + بحث + ترتيب
- Update: تعديل البيانات والصور
- Delete: تأكيد قبل الحذف

Fields:
- name (نص)
- specialty (نص)
- bio (نص طويل)
- experience_years (رقم)
- rating (رقم 1-5)
- consultation_price (رقم)
- image_url (رابط)
- is_active (منطقي)
```

### إدارة الأدوية (Admin)
```
CRUD Operations:
- Create: نموذج مع رفع صورة
- Read: بطاقات مع صور + بحث
- Update: تعديل شامل
- Delete: تأكيد

Fields:
- name (نص)
- generic_name (نص)
- active_ingredient (نص)
- indications (نص طويل)
- dosage (نص)
- side_effects (نص طويل)
- image_url (رابط)
- category (نص)
```

### نموذج التواصل
```
Fields:
- name (مطلوب)
- email (مطلوب، validation)
- phone (اختياري)
- session_type (radio: فيديو/صوت/رسائل)
- message (مطلوب)
- consent checkbox

Actions:
- Submit → validation → API call → success/error message
```

### حالات الأخطاء
- **Network error**: رسالة "حدث خطأ في الاتصال، حاول مرة أخرى"
- **Validation error**: إظهار الأخطاء تحت الحقول
- **404**: صفحة مخصصة مع رابط للرئيسية
- **Empty states**: رسائل تشجيعية مع صور

## 5. مخزون المكونات

### Buttons
```
Primary: خلفية primary، نص أبيض
Secondary: حدود primary، خلفية شفافة
Ghost: بدون حدود، نص primary
Disabled: opacity 0.5، cursor not-allowed
Loading: spinner داخلي
Sizes: sm (32px), md (40px), lg (48px)
```

### Cards
```
Doctor Card:
- صورة دائرية (100px)
- اسم بخط Cairo Bold
- تخصص
- تقييم نجوم (5)
- سنوات الخبرة
- سعر الاستشارة
- زر حجز

Medication Card:
- صورة مستطيلة (aspect 4:3)
- اسم الدواء
- المادة الفعالة
- دواعي الاستعمال (مقتطف)
- زر تفاصيل

Service Card:
- أيقونة SVG (48px)
- عنوان
- وصف
- زر
```

### Forms
```
Input:
- Label فوق الحقل
- Border: 1px solid gray
- Focus: border primary + shadow
- Error: border error + رسالة
- RTL text direction

Textarea:
- نفس نمط Input
- ارتفاع minimum 120px

Select:
- Custom dropdown
- أيقونة chevron
- Options مع RTL

Radio/Checkbox:
- Custom styling
- Animated check
```

### Navigation
```
Header (sticky):
- خلفية بيضاء مع shadow خفيف
- Logo يسار
- NavCenter
- Actions يمين
- Mobile: hamburger menu

Footer:
- خلفية primary داكنة
- 4 أعمدة
- روابط سريعة
- معلومات الاتصال
- Social links
- Copyright
```

### Modal
```
- Overlay: rgba(0,0,0,0.5)
- Box: خلفية بيضاء، border-radius 16px
- Header: عنوان + زر إغلاق
- Body: محتوى قابل للتمرير
- Footer: أزرار
- Animation: fade + scale
```

### Toast Notifications
```
- Position: top-right
- Types: success (أخضر), error (أحمر), info (أزرق)
- Auto-dismiss: 5 seconds
- Manual dismiss: X button
- Animation: slide-in from right
```

## 6. النهج التقني

### البنية التقنية
```
Frontend: Next.js 14 (App Router)
Styling: Tailwind CSS
Components: shadcn/ui
Icons: Lucide React
Forms: React Hook Form + Zod
State: Zustand (client) + React Query (server)
Animation: Framer Motion

Backend: Supabase
- PostgreSQL Database
- Authentication (Auth)
- Storage (للهوية والأدوية)
- Realtime subscriptions
- Row Level Security (RLS)
```

### هيكل قاعدة البيانات

#### Table: profiles
```sql
id: uuid (FK → auth.users)
full_name: text
phone: text
avatar_url: text
role: text ('user' | 'admin')
created_at: timestamp
updated_at: timestamp
```

#### Table: doctors
```sql
id: uuid
name: text
specialty: text
bio: text
experience_years: integer
rating: decimal
consultation_price: decimal
image_url: text
is_active: boolean
created_at: timestamp
updated_at: timestamp
```

#### Table: medications
```sql
id: uuid
name: text
generic_name: text
active_ingredient: text
indications: text
dosage: text
side_effects: text
image_url: text
category: text
is_active: boolean
created_at: timestamp
updated_at: timestamp
```

#### Table: bookings
```sql
id: uuid
user_id: uuid (FK → auth.users, nullable)
doctor_id: uuid (FK → doctors)
session_type: text ('video' | 'voice' | 'text')
patient_name: text
patient_email: text
patient_phone: text
notes: text
status: text ('pending' | 'confirmed' | 'completed' | 'cancelled')
scheduled_at: timestamp
created_at: timestamp
updated_at: timestamp
```

#### Table: contacts
```sql
id: uuid
name: text
email: text
phone: text
session_type: text
message: text
is_read: boolean
created_at: timestamp
```

### Supabase Storage Buckets
```
avatars/          - صور الأطباء والملفات الشخصية
medications/      - صور الأدوية
documents/        - المستندات الطبية (اختياري)
```

### Row Level Security Policies
```sql
-- Profiles: المستخدم يرى ملفه فقط، Admin يرى الكل
-- Doctors: الجميع يقرأ، Admin يضيف/يعدّل
-- Medications: الجميع يقرأ، Admin يضيف/يعدّل
-- Bookings: المستخدم يرى حجوزاته، Admin يرى الكل
-- Contacts: Admin فقط يقرأ/يحذف
```

### API Endpoints (Server Actions)
```typescript
// Doctors
getDoctors() → Doctor[]
getDoctorById(id) → Doctor
createDoctor(data) → Doctor (admin)
updateDoctor(id, data) → Doctor (admin)
deleteDoctor(id) → void (admin)

// Medications
getMedications() → Medication[]
getMedicationById(id) → Medication
createMedication(data) → Medication (admin)
updateMedication(id, data) → Medication (admin)
deleteMedication(id) → void (admin)

// Bookings
getBookings() → Booking[] (filtered by user or admin)
createBooking(data) → Booking
updateBookingStatus(id, status) → Booking (admin)

// Contacts
getContacts() → Contact[] (admin)
createContact(data) → Contact
markContactAsRead(id) → Contact (admin)
```

### Environment Variables
```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

## 7. خطوات التطوير

### المرحلة 1: الإعداد
- [x] إنشاء SPEC.md
- [ ] إعداد Supabase project
- [ ] إنشاء Next.js project
- [ ] تثبيت التبعيات
- [ ] إعداد Supabase client

### المرحلة 2: قاعدة البيانات
- [ ] إنشاء الجداول في Supabase
- [ ] إعداد RLS policies
- [ ] إنشاء Storage buckets
- [ ] إضافة بيانات تجريبية

### المرحلة 3: الواجهة الأساسية
- [ ] Layout و Navigation
- [ ] Homepage
- [ ] Services page
- [ ] Footer

### المرحلة 4: الميزات الأساسية
- [ ] صفحة الأطباء
- [ ] صفحة الأدوية
- [ ] نموذج التواصل
- [ ] صفحة الحجز

### المرحلة 5: لوحة التحكم
- [ ] Authentication
- [ ] Dashboard Overview
- [ ] إدارة الأطباء
- [ ] إدارة الأدوية
- [ ] إدارة الحجوزات

### المرحلة 6: الاختبار والنشر
- [ ] اختبار responsive
- [ ] اختبار functional
- [ ] رفع على Vercel
- [ ] إعداد الدومين المخصص

---

**ملاحظة**: هذا المشروع يتطلب:
1. حساب Supabase (مجاني)
2. Node.js 18+
3. حساب Vercel للنشر (مجاني)
